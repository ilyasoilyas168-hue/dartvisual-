package com.dartvisual.client.mixin;

import com.dartvisual.client.DartVisual;
import com.dartvisual.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class MixinInGameHud {

    @Inject(method = "render", at = @At("TAIL"))
    private void dartvisual$renderHud(DrawContext ctx, RenderTickCounter counter, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        // Показываем активные модули в углу экрана (как в PulseVisual)
        int x = 2;
        int y = 2;
        int color_accent = 0xFF7B2FFF;
        int color_text   = 0xFFEEEEEE;

        // Логотип DartVisual
        ctx.drawText(client.textRenderer, "§bDart§dVisual", x, y, color_text, true);
        y += 10;

        // Список включённых модулей
        for (Module m : DartVisual.moduleManager.getModules()) {
            if (m.isEnabled()) {
                ctx.fill(x, y, x + 4, y + 8, color_accent);
                ctx.drawText(client.textRenderer, "§7" + m.getName(), x + 6, y, color_text, true);
                y += 10;
            }
        }
    }
}
