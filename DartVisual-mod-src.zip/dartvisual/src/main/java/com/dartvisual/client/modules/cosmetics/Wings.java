package com.dartvisual.client.modules.cosmetics;

import com.dartvisual.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

// ===================== КРЫЛЬЯ =====================
public class Wings extends Module {
    public Wings() {
        super("Крылья", "Красивые крылья за спиной игрока из частиц", Category.КОСМЕТИКА);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        Vec3d pos = client.player.getPos();
        float yaw = client.player.getYaw();
        double rad = Math.toRadians(yaw + 90);

        if (client.player.age % 2 == 0) {
            // Левое крыло
            for (int i = 1; i <= 4; i++) {
                double wx = pos.x + Math.cos(rad) * i * 0.3;
                double wy = pos.y + 1.2 + i * 0.15;
                double wz = pos.z + Math.sin(rad) * i * 0.3;
                client.world.addParticle(ParticleTypes.END_ROD, wx, wy, wz,
                        0, 0.01, 0);
            }
            // Правое крыло
            for (int i = 1; i <= 4; i++) {
                double wx = pos.x - Math.cos(rad) * i * 0.3;
                double wy = pos.y + 1.2 + i * 0.15;
                double wz = pos.z - Math.sin(rad) * i * 0.3;
                client.world.addParticle(ParticleTypes.END_ROD, wx, wy, wz,
                        0, 0.01, 0);
            }
        }
    }
}

// ===================== СЛЕД =====================
class Trail extends Module {
    public Trail() {
        super("След", "Красивый след из частиц за игроком при движении", Category.КОСМЕТИКА);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (!client.player.isSprinting()) return;

        Vec3d pos = client.player.getPos();
        for (int i = 0; i < 3; i++) {
            double x = pos.x + (Math.random() - 0.5) * 0.4;
            double y = pos.y + Math.random() * 0.5;
            double z = pos.z + (Math.random() - 0.5) * 0.4;
            client.world.addParticle(ParticleTypes.DRAGON_BREATH, x, y, z,
                    0, 0.02, 0);
        }
    }
}

// ===================== ШЛЯПА =====================
class Hat extends Module {
    public Hat() {
        super("Шляпа", "Декоративные частицы вокруг головы игрока", Category.КОСМЕТИКА);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (client.player.age % 4 == 0) {
            Vec3d pos = client.player.getPos();
            double angle = (client.player.age * 15) % 360;
            double rad = Math.toRadians(angle);
            double x = pos.x + Math.cos(rad) * 0.4;
            double z = pos.z + Math.sin(rad) * 0.4;
            client.world.addParticle(ParticleTypes.TOTEM_OF_UNDYING,
                    x, pos.y + 1.9, z, 0, 0.02, 0);
        }
    }
}

// ===================== АУРА =====================
class Aura extends Module {
    public Aura() {
        super("Аура", "Магическая аура вокруг игрока из частиц энергии", Category.КОСМЕТИКА);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (client.player.age % 2 == 0) {
            Vec3d pos = client.player.getPos();
            double angle = (client.player.age * 10) % 360;
            double rad = Math.toRadians(angle);
            double x = pos.x + Math.cos(rad) * 1.0;
            double z = pos.z + Math.sin(rad) * 1.0;
            client.world.addParticle(ParticleTypes.ENCHANT,
                    x, pos.y + 1.0, z,
                    -Math.cos(rad) * 0.05, 0.05, -Math.sin(rad) * 0.05);
        }
    }
}
