package com.dartvisual.client.modules;

import net.minecraft.client.MinecraftClient;

public abstract class Module {

    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;

    public enum Category {
        УТИЛИТЫ("⚙ Утилиты"),
        ВИЗУАЛ("✨ Визуал"),
        КОСМЕТИКА("👑 Косметика"),
        ПВЕ("🐉 ПвЕ"),
        ПВП("⚔ ПвП");

        private final String displayName;

        Category(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = false;
    }

    public void toggle() {
        this.enabled = !this.enabled;
        if (this.enabled) onEnable();
        else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient client) {}

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
}
