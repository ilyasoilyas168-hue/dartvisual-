package com.dartvisual.client;

import com.dartvisual.client.gui.DartGuiScreen;
import com.dartvisual.client.keybind.KeyBindManager;
import com.dartvisual.client.modules.ModuleManager;
import com.dartvisual.client.effects.ParticleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DartVisual implements ClientModInitializer {

    public static final String MOD_ID = "dartvisual";
    public static final String MOD_NAME = "DartVisual";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    public static DartVisual INSTANCE;
    public static ModuleManager moduleManager;
    public static ParticleManager particleManager;

    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        LOGGER.info("DartVisual запускается...");

        moduleManager = new ModuleManager();
        particleManager = new ParticleManager();

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.dartvisual.opengui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.dartvisual"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiKey.wasPressed()) {
                client.setScreen(new DartGuiScreen());
            }
            moduleManager.onTick(client);
            particleManager.onTick(client);
        });

        LOGGER.info("DartVisual загружен! Нажми RSHIFT для меню.");
    }

    public static MinecraftClient getClient() {
        return MinecraftClient.getInstance();
    }
}
