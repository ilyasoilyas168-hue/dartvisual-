package com.dartvisual.client.modules.utility;

import com.dartvisual.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.text.Text;

// ===================== АЛЕРТ БОССА =====================
public class BossAlert extends Module {
    public BossAlert() {
        super("АлертБосса", "Оповещает звуком и текстом когда поблизости появился босс", Category.ПВЕ);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null) return;
        if (!client.getBossBarHud().getBossBars().isEmpty()) {
            if (client.player.age % 100 == 0) {
                client.player.sendMessage(
                    Text.literal("§4⚠ DartVisual: §cБосс рядом!"), true
                );
            }
        }
    }
}

// ===================== РАДАР МОБОВ =====================
class MobRadar extends Module {
    public MobRadar() {
        super("РадарМобов", "Показывает враждебных мобов на миникарте/радаре", Category.ПВЕ);
    }

    @Override
    public void onTick(MinecraftClient client) {
        // Рендер через minimap overlay
    }
}

// ===================== ЛOOT ХЕЛПЕР =====================
class LootHelper extends Module {
    public LootHelper() {
        super("ЛутХелпер", "Подсвечивает редкие предметы на земле и в сундуках", Category.ПВЕ);
    }

    @Override
    public void onTick(MinecraftClient client) {
        // ESP для ItemEntity с высокой редкостью
    }
}

// ===================== АЛЕРТ СПАВНА =====================
class SpawnAlert extends Module {
    public SpawnAlert() {
        super("АлертСпавна", "Предупреждает если ты в зоне спавна мобов (низкая освещённость)", Category.ПВЕ);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        int lightLevel = client.world.getLightLevel(client.player.getBlockPos());
        if (lightLevel < 8 && client.player.age % 40 == 0) {
            client.player.sendMessage(
                Text.literal("§e⚠ DartVisual: §6Низкий свет — мобы заспавнятся!"), true
            );
        }
    }
}
