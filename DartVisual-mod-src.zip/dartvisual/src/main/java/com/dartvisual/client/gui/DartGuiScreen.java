package com.dartvisual.client.gui;

import com.dartvisual.client.DartVisual;
import com.dartvisual.client.modules.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public class DartGuiScreen extends Screen {

    // === ЦВЕТА ===
    private static final int COLOR_BG        = 0xE5101010; // тёмный фон
    private static final int COLOR_SIDEBAR    = 0xFF0D0D0D; // сайдбар
    private static final int COLOR_ACCENT     = 0xFF7B2FFF; // фиолетовый акцент
    private static final int COLOR_ACCENT2    = 0xFF4F8EFF; // синий
    private static final int COLOR_TEXT       = 0xFFEEEEEE;
    private static final int COLOR_SUBTEXT    = 0xFF888888;
    private static final int COLOR_ENABLED    = 0xFF7B2FFF;
    private static final int COLOR_DISABLED   = 0xFF2A2A2A;
    private static final int COLOR_HOVER      = 0xFF1E1E2E;
    private static final int COLOR_SELECTED_TAB = 0xFF1A1A2A;

    // === РАЗМЕРЫ ===
    private static final int WIN_W  = 420;
    private static final int WIN_H  = 280;
    private static final int SIDE_W = 110;
    private static final int MOD_H  = 30;

    private int winX, winY;
    private int selectedCat = 0;
    private int scrollOffset = 0;
    private int hoveredModule = -1;
    private boolean dragging = false;
    private double dragOffX, dragOffY;

    private final Module.Category[] categories = Module.Category.values();

    public DartGuiScreen() {
        super(Text.literal("DartVisual"));
    }

    @Override
    protected void init() {
        winX = (this.width - WIN_W) / 2;
        winY = (this.height - WIN_H) / 2;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Затемнение фона
        ctx.fill(0, 0, this.width, this.height, 0x88000000);

        // Главное окно
        drawRoundRect(ctx, winX, winY, WIN_W, WIN_H, COLOR_BG);

        // Шапка
        drawHeader(ctx, mouseX, mouseY);

        // Левая панель — категории
        drawSidebar(ctx, mouseX, mouseY);

        // Правая панель — модули
        drawModules(ctx, mouseX, mouseY);

        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawHeader(DrawContext ctx, int mx, int my) {
        // Верхняя полоска с градиентом (акцент)
        ctx.fillGradient(winX, winY, winX + WIN_W, winY + 3,
                COLOR_ACCENT, COLOR_ACCENT2);

        // Лого и название
        ctx.drawText(textRenderer, "§b§lDart§d§lVisual", winX + 10, winY + 8, COLOR_TEXT, false);
        ctx.drawText(textRenderer, "§8v1.0 | 1.21.4 Fabric", winX + 10, winY + 18, COLOR_SUBTEXT, false);

        // Кнопка закрыть
        int cx = winX + WIN_W - 18;
        int cy = winY + 8;
        boolean hov = mx >= cx && mx <= cx + 14 && my >= cy && my <= cy + 12;
        ctx.fill(cx, cy, cx + 14, cy + 12, hov ? 0xFFCC3333 : 0xFF2A2A2A);
        ctx.drawText(textRenderer, "§c✕", cx + 3, cy + 2, COLOR_TEXT, false);

        // Разделитель
        ctx.fill(winX, winY + 30, winX + WIN_W, winY + 31, 0xFF222233);
    }

    private void drawSidebar(DrawContext ctx, int mx, int my) {
        ctx.fill(winX, winY + 31, winX + SIDE_W, winY + WIN_H, COLOR_SIDEBAR);
        ctx.fill(winX + SIDE_W - 1, winY + 31, winX + SIDE_W, winY + WIN_H, 0xFF222233);

        for (int i = 0; i < categories.length; i++) {
            int ty = winY + 38 + i * 36;
            boolean sel = (i == selectedCat);
            boolean hov = mx >= winX && mx <= winX + SIDE_W - 1
                    && my >= ty - 3 && my <= ty + 25;

            // Фон таба
            if (sel) {
                ctx.fill(winX, ty - 3, winX + SIDE_W - 1, ty + 25, COLOR_SELECTED_TAB);
                // Акцентная полоска слева
                ctx.fill(winX, ty - 3, winX + 3, ty + 25, COLOR_ACCENT);
            } else if (hov) {
                ctx.fill(winX, ty - 3, winX + SIDE_W - 1, ty + 25, COLOR_HOVER);
            }

            // Текст категории
            String label = categories[i].getDisplayName();
            int count = DartVisual.moduleManager.getByCategory(categories[i]).size();
            long enabled = DartVisual.moduleManager.getByCategory(categories[i]).stream()
                    .filter(Module::isEnabled).count();

            ctx.drawText(textRenderer, sel ? "§b" + label : "§7" + label,
                    winX + 10, ty + 2, COLOR_TEXT, false);
            ctx.drawText(textRenderer, "§8" + enabled + "/" + count,
                    winX + 10, ty + 12, COLOR_SUBTEXT, false);
        }
    }

    private void drawModules(DrawContext ctx, int mx, int my) {
        List<Module> mods = DartVisual.moduleManager.getByCategory(categories[selectedCat]);

        int panelX = winX + SIDE_W + 5;
        int panelY = winY + 36;
        int panelW = WIN_W - SIDE_W - 10;

        // Заголовок категории
        ctx.drawText(textRenderer, "§b" + categories[selectedCat].getDisplayName(),
                panelX, panelY, COLOR_TEXT, false);
        ctx.fill(panelX, panelY + 10, panelX + panelW, panelY + 11, COLOR_ACCENT);

        int startY = panelY + 18;
        int visibleH = WIN_H - 60;
        int maxScroll = Math.max(0, mods.size() * MOD_H - visibleH);
        scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));

        hoveredModule = -1;
        for (int i = 0; i < mods.size(); i++) {
            Module m = mods.get(i);
            int my2 = startY + i * MOD_H - scrollOffset;

            if (my2 < startY - MOD_H || my2 > winY + WIN_H - 10) continue;

            boolean hov = mx >= panelX && mx <= panelX + panelW - 5
                    && my >= my2 && my <= my2 + MOD_H - 2;
            if (hov) hoveredModule = i;

            // Фон модуля
            int bgColor = hov ? COLOR_HOVER : 0xFF141414;
            ctx.fill(panelX, my2, panelX + panelW - 5, my2 + MOD_H - 2, bgColor);

            // Левая полоска (включён/выключен)
            ctx.fill(panelX, my2, panelX + 2, my2 + MOD_H - 2,
                    m.isEnabled() ? COLOR_ENABLED : COLOR_DISABLED);

            // Название модуля
            String nameColor = m.isEnabled() ? "§b" : "§7";
            ctx.drawText(textRenderer, nameColor + m.getName(),
                    panelX + 8, my2 + 5, COLOR_TEXT, false);

            // Описание
            ctx.drawText(textRenderer, "§8" + truncate(m.getDescription(), 34),
                    panelX + 8, my2 + 16, COLOR_SUBTEXT, false);

            // Тоггл кнопка (справа)
            int btnX = panelX + panelW - 32;
            int btnY = my2 + 8;
            drawToggle(ctx, btnX, btnY, m.isEnabled());
        }
    }

    private void drawToggle(DrawContext ctx, int x, int y, boolean on) {
        int w = 26, h = 12;
        int bg = on ? COLOR_ACCENT : 0xFF333333;
        ctx.fill(x, y, x + w, y + h, bg);
        // Кружочек
        int kx = on ? x + w - h + 1 : x + 1;
        ctx.fill(kx, y + 1, kx + h - 2, y + h - 1, 0xFFFFFFFF);
    }

    private void drawRoundRect(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x + 2, y, x + w - 2, y + h, color);
        ctx.fill(x, y + 2, x + w, y + h - 2, color);
        ctx.fill(x + 1, y + 1, x + w - 1, y + h - 1, color);
    }

    private String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() > max ? s.substring(0, max - 2) + "…" : s;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int imx = (int) mx, imy = (int) my;

        // Клик по кнопке закрыть
        int cx = winX + WIN_W - 18, cy = winY + 8;
        if (imx >= cx && imx <= cx + 14 && imy >= cy && imy <= cy + 12) {
            this.close();
            return true;
        }

        // Перетаскивание окна (по заголовку)
        if (imx >= winX && imx <= winX + WIN_W - 20
                && imy >= winY && imy <= winY + 30) {
            dragging = true;
            dragOffX = mx - winX;
            dragOffY = my - winY;
            return true;
        }

        // Клик по категории
        for (int i = 0; i < categories.length; i++) {
            int ty = winY + 38 + i * 36;
            if (imx >= winX && imx <= winX + SIDE_W - 1
                    && imy >= ty - 3 && imy <= ty + 25) {
                selectedCat = i;
                scrollOffset = 0;
                return true;
            }
        }

        // Клик по модулю
        List<Module> mods = DartVisual.moduleManager.getByCategory(categories[selectedCat]);
        int panelX = winX + SIDE_W + 5;
        int panelW = WIN_W - SIDE_W - 10;
        int startY = winY + 54;

        for (int i = 0; i < mods.size(); i++) {
            int modY = startY + i * MOD_H - scrollOffset;
            if (imx >= panelX && imx <= panelX + panelW - 5
                    && imy >= modY && imy <= modY + MOD_H - 2) {
                mods.get(i).toggle();
                return true;
            }
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            winX = (int) (mx - dragOffX);
            winY = (int) (my - dragOffY);
            winX = Math.max(0, Math.min(winX, this.width - WIN_W));
            winY = Math.max(0, Math.min(winY, this.height - WIN_H));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        scrollOffset -= (int)(vAmount * 10);
        return true;
    }

    @Override
    public boolean shouldPause() { return false; }
}
