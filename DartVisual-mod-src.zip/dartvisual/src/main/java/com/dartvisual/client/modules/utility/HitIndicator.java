package com.dartvisual.client.modules.utility;

import com.dartvisual.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

// ===================== ХИТ ИНДИКАТОР =====================
public class HitIndicator extends Module {
    public HitIndicator() {
        super("ХитИндикатор", "Показывает визуальный эффект при ударе по врагу", Category.ПВП);
    }

    @Override
    public void onTick(MinecraftClient client) {
        // Интегрируется с ParticleManager при ударе
    }
}
