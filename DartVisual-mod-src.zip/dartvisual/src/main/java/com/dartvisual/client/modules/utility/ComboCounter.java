package com.dartvisual.client.modules.utility;

import com.dartvisual.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.text.Text;

// ===================== КОМБО СЧЁТЧИК =====================
public class ComboCounter extends Module {
    private int combo = 0;
    private int resetTimer = 0;

    public ComboCounter() {
        super("КомбоСчётчик", "Считает комбо ударов в ПвП и показывает на экране", Category.ПВП);
    }

    public void registerHit() {
        combo++;
        resetTimer = 60; // 3 секунды до сброса
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (resetTimer > 0) resetTimer--;
        else combo = 0;

        if (client.player != null && combo > 1) {
            client.player.sendMessage(
                Text.literal("§e⚔ Комбо: §f" + combo + "x"), true
            );
        }
    }

    public int getCombo() { return combo; }
}

// ===================== СТАТУС БРОНИ =====================
class ArmorStatus extends Module {
    public ArmorStatus() {
        super("СтатусБрони", "Показывает прочность брони в HUD над инвентарём", Category.ПВП);
    }

    @Override
    public void onTick(MinecraftClient client) {
        // Рендер через HUD mixin
    }
}

// ===================== ТАЙМЕР ЗЕЛИЙ =====================
class PotionTimer extends Module {
    public PotionTimer() {
        super("ТаймерЗелий", "Показывает оставшееся время эффектов зелий на экране", Category.ПВП);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null) return;
        // Отображается через HUD рендер
        for (StatusEffectInstance effect : client.player.getStatusEffects()) {
            int duration = effect.getDuration();
            // Рендер тиков в секунды: duration / 20
        }
    }
}
