package com.dartvisual.client.modules.utility;

import com.dartvisual.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.*;
import net.minecraft.entity.player.PlayerInventory;

public class HealingHelper extends Module {

    private int cooldown = 0;

    public HealingHelper() {
        super("Лечение", "Напоминает и помогает с лечением — еда, зелья, регенерация", Category.УТИЛИТЫ);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null) return;
        if (cooldown > 0) { cooldown--; return; }

        float hp = client.player.getHealth();
        float maxHp = client.player.getMaxHealth();

        // Если HP ниже 50% — ищем еду или зелье лечения в хотбаре
        if (hp < maxHp * 0.5f) {
            PlayerInventory inv = client.player.getInventory();
            for (int i = 0; i < 9; i++) {
                ItemStack stack = inv.getStack(i);
                Item item = stack.getItem();

                if (item instanceof PotionItem) {
                    inv.selectedSlot = i;
                    cooldown = 40;
                    break;
                }

                if (item.isFood() && client.player.canConsume(false)) {
                    inv.selectedSlot = i;
                    cooldown = 20;
                    break;
                }
            }
        }
    }
}
