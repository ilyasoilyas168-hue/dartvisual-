package com.dartvisual.client.modules.visual;

import com.dartvisual.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

// ===================== CHINA HEAT =====================
public class ChinaHeat extends Module {
    public ChinaHeat() {
        super("ChinaHeat", "Эффект волн жара вокруг игрока — как в китайских видео", Category.ВИЗУАЛ);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        Vec3d pos = client.player.getPos();
        if (client.player.age % 3 == 0) {
            for (int i = 0; i < 6; i++) {
                double angle = (Math.PI * 2 / 6) * i;
                double x = pos.x + Math.cos(angle) * 0.8;
                double z = pos.z + Math.sin(angle) * 0.8;
                client.world.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                        x, pos.y + 0.1, z, 0, 0.01, 0);
            }
        }
    }
}

// ===================== JUMP CIRCLE =====================
class JumpCircle extends Module {
    public JumpCircle() {
        super("JumpCircle", "Кольцо частиц под ногами при прыжке", Category.ВИЗУАЛ);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (client.player.isJumping()) {
            Vec3d pos = client.player.getPos();
            for (int i = 0; i < 12; i++) {
                double angle = (Math.PI * 2 / 12) * i;
                double x = pos.x + Math.cos(angle) * 0.6;
                double z = pos.z + Math.sin(angle) * 0.6;
                client.world.addParticle(ParticleTypes.CRIT,
                        x, pos.y, z,
                        Math.cos(angle) * 0.05, 0.02, Math.sin(angle) * 0.05);
            }
        }
    }
}

// ===================== HIT PARTICLE =====================
class HitParticle extends Module {
    public HitParticle() {
        super("HitParticle", "Красивые частицы при ударе по мобу или игроку", Category.ВИЗУАЛ);
    }

    public void spawnHitEffect(MinecraftClient client, Vec3d pos) {
        if (client.world == null) return;
        for (int i = 0; i < 8; i++) {
            double vx = (Math.random() - 0.5) * 0.3;
            double vy = Math.random() * 0.2;
            double vz = (Math.random() - 0.5) * 0.3;
            client.world.addParticle(ParticleTypes.CRIT, pos.x, pos.y + 1, pos.z, vx, vy, vz);
        }
    }

    @Override
    public void onTick(MinecraftClient client) {}
}

// ===================== AMBIENCE =====================
class Ambience extends Module {
    public Ambience() {
        super("Ambience", "Атмосферные частицы вокруг игрока — магия, звёзды, листья", Category.ВИЗУАЛ);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (client.player.age % 10 == 0) {
            Vec3d pos = client.player.getPos();
            double x = pos.x + (Math.random() - 0.5) * 2;
            double y = pos.y + Math.random() * 2;
            double z = pos.z + (Math.random() - 0.5) * 2;
            client.world.addParticle(ParticleTypes.ENCHANT, x, y, z,
                    (Math.random() - 0.5) * 0.1, 0.05, (Math.random() - 0.5) * 0.1);
        }
    }
}

// ===================== WORLD PARTICLE =====================
class WorldParticle extends Module {
    public WorldParticle() {
        super("WorldParticle", "Красивые частицы по всему миру — магия, природа, атмосфера", Category.ВИЗУАЛ);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        if (client.player.age % 20 == 0) {
            Vec3d pos = client.player.getPos();
            for (int i = 0; i < 3; i++) {
                double x = pos.x + (Math.random() - 0.5) * 10;
                double y = pos.y + Math.random() * 5;
                double z = pos.z + (Math.random() - 0.5) * 10;
                client.world.addParticle(ParticleTypes.SPORE_BLOSSOM_AIR, x, y, z, 0, -0.01, 0);
            }
        }
    }
}

// ===================== BLOCK OUTLINE =====================
class BlockOutline extends Module {
    public BlockOutline() {
        super("ПодсветкаБлоков", "Красивая подсветка блоков на которые смотришь", Category.ВИЗУАЛ);
    }

    @Override
    public void onTick(MinecraftClient client) {
        // Рендер через mixin на WorldRenderer
    }
}

// ===================== FULLBRIGHT =====================
class Fullbright extends Module {
    private float prevGamma = 1.0f;

    public Fullbright() {
        super("Яркость", "Максимальная яркость — видно всё в темноте без читов", Category.ВИЗУАЛ);
    }

    @Override
    public void onEnable() {
        MinecraftClient client = MinecraftClient.getInstance();
        prevGamma = client.options.getGamma().getValue().floatValue();
        client.options.getGamma().setValue(10.0);
    }

    @Override
    public void onDisable() {
        MinecraftClient.getInstance().options.getGamma().setValue((double) prevGamma);
    }

    @Override
    public void onTick(MinecraftClient client) {}
}
