package com.dartvisual.client.modules;

import com.dartvisual.client.modules.utility.*;
import com.dartvisual.client.modules.visual.*;
import com.dartvisual.client.modules.cosmetics.*;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // ⚙ УТИЛИТЫ
        register(new AutoSwap());
        register(new HealingHelper());
        register(new MineHelper());
        register(new AutoMark());
        register(new ItemHelper());
        register(new FoodHelper());
        register(new ToolSaver());

        // ⚔ ПВП
        register(new HitIndicator());
        register(new ComboCounter());
        register(new ArmorStatus());
        register(new PotionTimer());

        // 🐉 ПВЕ
        register(new BossAlert());
        register(new MobRadar());
        register(new LootHelper());
        register(new SpawnAlert());

        // ✨ ВИЗУАЛ
        register(new ChinaHeat());
        register(new JumpCircle());
        register(new HitParticle());
        register(new Ambience());
        register(new WorldParticle());
        register(new BlockOutline());
        register(new Fullbright());

        // 👑 КОСМЕТИКА
        register(new Wings());
        register(new Trail());
        register(new Hat());
        register(new Aura());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public void onTick(MinecraftClient client) {
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick(client);
        }
    }

    public List<Module> getModules() { return modules; }

    public List<Module> getByCategory(Module.Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) result.add(m);
        }
        return result;
    }

    public Module getByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) return m;
        }
        return null;
    }
}
