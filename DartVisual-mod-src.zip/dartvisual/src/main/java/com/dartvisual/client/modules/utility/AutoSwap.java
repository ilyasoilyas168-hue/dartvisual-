package com.dartvisual.client.modules.utility;

import com.dartvisual.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.*;
import net.minecraft.entity.player.PlayerInventory;

public class AutoSwap extends Module {

    public AutoSwap() {
        super("АвтоСмена", "Автоматически меняет предмет в руке (еда, оружие, инструмент)", Category.УТИЛИТЫ);
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null) return;
        PlayerInventory inv = client.player.getInventory();
        ItemStack mainHand = inv.getMainHandStack();

        // Если в руке ничего нет — найти лучший предмет
        if (mainHand.isEmpty()) {
            for (int i = 0; i < 9; i++) {
                ItemStack stack = inv.getStack(i);
                if (stack.getItem() instanceof SwordItem || stack.getItem() instanceof AxeItem) {
                    inv.selectedSlot = i;
                    break;
                }
            }
        }
    }
}
