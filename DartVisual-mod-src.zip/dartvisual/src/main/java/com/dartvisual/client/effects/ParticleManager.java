package com.dartvisual.client.effects;

import net.minecraft.client.MinecraftClient;

public class ParticleManager {

    public void onTick(MinecraftClient client) {
        // Централизованное управление частицами
        // Вызывается каждый тик из основного класса
    }

    public void spawnRing(MinecraftClient client, double x, double y, double z,
                           int count, double radius, net.minecraft.particle.ParticleEffect particle) {
        if (client.world == null) return;
        for (int i = 0; i < count; i++) {
            double angle = (Math.PI * 2 / count) * i;
            double px = x + Math.cos(angle) * radius;
            double pz = z + Math.sin(angle) * radius;
            client.world.addParticle(particle, px, y, pz, 0, 0, 0);
        }
    }
}
